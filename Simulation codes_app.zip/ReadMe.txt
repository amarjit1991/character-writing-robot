You will have to install jdk to run the simulation
jdk1.6+ is recommended

To run the applet, paste the CWR2.java and CWR2.html file in the bin folder of your jdk
The compile the applet using 
	javac CWR2.java
To run the applet, use 
	appletviewer CWR2.html

You can directly run the applet without compiling if you have the compiled classes
Make sure you have CWR2.class, Frame_Type.class, CoOrdinate.class and Link.class in your bin
Make sure you also have the html file
Then run the applet using
	appletviewer CWR2.html
