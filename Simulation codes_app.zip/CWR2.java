import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

//CoOrdinate class to store cartesian points as an object
class CoOrdinate
{

	//X Y co-ordinates of a point
	int x, y;

}

//Link Objects represent each link on the robot
class Link
{

	//Private Data Members
	//point of origin axle of the motor
	private int originX, originY;
	//width of the link
	private double width = 50;
	//current angle of the link with respect to real X axis
	private double angle = 90;
	//backward extension of link.. distance fron origin to rearest point
	private int backOffset = 25;
	//distance from origin to farthest point
	private int frontOffset;
	//real length of the link
	private int length;

	//public Data Members
	//link joined to current link
	public Link l;
	//link to which current link is joined
	public Link bl;

	//Constructor
	Link(int x, int y, int l)
	{

		originX = x;
		originY = y;
		length = l*10;
		frontOffset = length + 25;

	}

	//Set Origin
	public void setXY(int x, int y)
	{

		originX = x;
		originY = y;

	}

	public int getOriginX()
	{

		return originX;

	}

	public int getOriginY()
	{

		return originY;

	}
	public void setWidth( double w )
	{

		width = w;

	}

	public void setAngle( double a )
	{

		angle = a;

	}

	public double getAngle()
	{

		return angle;

	}

	public void setBackOffset( int b )
	{

		backOffset = b;

	}

	public void setFrontOffset( int f )
	{

		frontOffset = f;

	}

	public void setLength( int l )
	{

		length = l;

	}

	public double getLength()
	{

		return length;
	}

	//Draws the Link on the applet at the origin of the link
	public void draw(Graphics g, boolean penFlag)
	{

		double angle = Math.toRadians(this.angle);
		double w = width/2;
		//g.drawArc( (int)(originX - w), (int)(originY - w), (int)(width), (int)(width), 0, 360);

		CoOrdinate A = new CoOrdinate();
		A.x = (int)( originX + w * Math.sin(angle) );
		A.y = (int)( originY + w * Math.cos(angle) );

		CoOrdinate B = new CoOrdinate();
		B.x = (int)( A.x + frontOffset*Math.cos(angle) );
		B.y = (int)( A.y - frontOffset*Math.sin(angle) );

		CoOrdinate C = new CoOrdinate();
		C.x = (int)( B.x - width*Math.sin(angle) );
		C.y = (int)( B.y - width*Math.cos(angle) );

		CoOrdinate D = new CoOrdinate();
		D.x = (int)( C.x - (frontOffset + backOffset)*Math.cos(angle) );
		D.y = (int)( C.y + (frontOffset + backOffset)*Math.sin(angle) );

		CoOrdinate E = new CoOrdinate();
		E.x = (int)( D.x + width*Math.sin(angle) );
		E.y = (int)( D.y + width*Math.cos(angle) );

		g.setColor(Color.black);
		/*g.drawLine(A.x, A.y, B.x, B.y);
		g.drawLine(B.x, B.y, C.x, C.y);
		g.drawLine(C.x, C.y, D.x, D.y);
		g.drawLine(D.x, D.y, E.x, E.y);
		g.drawLine(E.x, E.y, A.x, A.y);*/

		if(bl == null)
			g.setColor(new Color(160,160,160));
		else
			g.setColor(new Color(196,196,196));
		int X[] = {A.x,B.x,C.x,D.x,E.x};
		int Y[] = {A.y,B.y,C.y,D.y,E.y};
		g.fillPolygon(X, Y, 5);

		g.setColor(Color.yellow);
		g.fillArc( (int)(originX - w), (int)(originY - w), (int)(width), (int)(width), 0, 360);


		if(bl != null )
		{

			if(penFlag)
			{

				g.setColor(Color.black);
				CoOrdinate temp = new CoOrdinate();
				getTip(temp);
				g.drawArc( temp.x-10, temp.y-10, 20, 20, 0, 360 );

			}
			else
			{

				g.setColor(Color.black);
				CoOrdinate temp = new CoOrdinate();
				getTip(temp);

				temp.x = (int)( temp.x - 10 * Math.cos(angle) );
				temp.y = (int)( temp.y + 10 * Math.sin(angle) );

				A.x = (int)( temp.x + 50 * Math.sin(angle) );
				A.y = (int)( temp.y + 50 * Math.cos(angle) );

				B.x = (int)( A.x + 20 * Math.cos(angle) );
				B.y = (int)( A.y - 20 * Math.sin(angle) );

				C.x = (int)( B.x - 90 * Math.sin(angle) );
				C.y = (int)( B.y - 90 * Math.cos(angle) );

				D.x = (int)( A.x - 90 * Math.sin(angle) );
				D.y = (int)( A.y - 90 * Math.cos(angle) );

				E.x = (int)( D.x - 10 * Math.sin(angle) );
				E.y = (int)( D.y - 10 * Math.cos(angle) );

				CoOrdinate F = new CoOrdinate();
				F.x = (int)( E.x + 10 * Math.cos(angle) );
				F.y = (int)( E.y - 10 * Math.sin(angle) );

				int X1[] = { A.x, B.x, C.x, F.x, D.x };
				int Y1[] = { A.y, B.y, C.y, F.y, D.y };

				g.drawPolygon(X1, Y1, 5);

				//g.drawLine(D.x, D.y, F.x, F.y);


			}

		}

	}

	//rotate the link as the stepper motor would do
	public boolean rotate(int dir)
	{

		/*if(bl == null)
		{
			if( dir == 1 && angle >= maxAngle-1  )
				return false;
			else if( dir == -1 && angle <= minAngle+1 )
				return false;
		}
		else
		{
			if( dir == 1 && angle >= bl.angle+170-1  )
					return false;
			else if( dir == -1 && angle <= bl.angle-170+1 )
				return false;
		}*/

		angle += dir*6;

		if(l != null)
		{
			CoOrdinate temp = new CoOrdinate();
			temp.x = (int)( originX + length*Math.cos( Math.toRadians( angle ) ) );
			temp.y = (int)( originY - length*Math.sin( Math.toRadians( angle ) ) );

			l.setXY(temp.x, temp.y);

			l.rotate(dir);
		}

		return true;

	}

	//obtain the real tip of the link
	public void getTip(CoOrdinate tip)
	{

		tip.x = (int)( originX + length*Math.cos( Math.toRadians(angle) ) );
		tip.y = (int)( originY - length*Math.sin( Math.toRadians(angle) ) );

	}

	//obtain the tip of the link in character space
	public void getTipRef(CoOrdinate tip)
	{

			tip.x = (int)( originX + length*Math.cos( Math.toRadians(angle) ) );
			tip.y = (int)( originY - length*Math.sin( Math.toRadians(angle) ) );

			tip.x -= bl.getOriginX();
			tip.y -= bl.getOriginY();
			tip.y -= 50;

	}

	//drag the robot to required position horizontally
	public void drag(int d)
	{

		originX+=d;

		if(l != null)
		{
			CoOrdinate temp = new CoOrdinate();
			temp.x = (int)( originX + length*Math.cos( Math.toRadians( angle ) ) );
			temp.y = (int)( originY - length*Math.sin( Math.toRadians( angle ) ) );

			l.setXY(temp.x, temp.y);
		}

	}

}

class Frame_Type extends Frame implements ActionListener
{


	//Button to order robot to write
	Button write;
	//TextField to obtain User Input
	TextField input;
	//TextField to show connection
	TextField connection;
	//TextField to show status
	TextField status;
	//TextField to show port
	TextField port;
	//Button to connect to the robot
	Button connect;

	CWR2 c;

	Label conn;
	Label st;
	Label in;

	Frame_Type(CWR2 c)
	{

		this.c = c;

		//assign appropriate text messages with components
		write = new Button("write!");
		connect = new Button("Connect");
		input = new TextField("Write Here",20);
		connection = new TextField("Not Connected", 20);
		status = new TextField("Not Connected", 20);
		conn = new Label("Connection:");
		st = new Label("Status:");
		in = new Label("Input:");

		//custom layout
		this.setLayout(null);

		connection.setEditable(false);
		status.setEditable(false);
		connection.setBackground( new Color(255,0,0) );

		//set location
		connection.setBounds(86, 30, 91, 18);
		write.setBounds(86, 190, 91, 18);
		input.setBounds(86, 163, 91, 18);
		connect.setBounds(86, 86, 91, 18);
		status.setBounds(86, 57, 91,18);

		conn.setBounds(5, 30, 100, 18);
		st.setBounds(5, 57, 100, 18);
		in.setBounds(5, 163, 100, 18);

		//add the components in the GUI
		add( write );
		add( input );
		add(connection);
		add(connect);
		add(status);
		add(conn);
		add(st);
		add(in);

		//Listen to buttons
		write.addActionListener(this);
		connect.addActionListener(this);

	}


	public void actionPerformed(ActionEvent evt)
	{

		//if button pressed to write the text on screen
		if (evt.getSource() == write)
		{

			//check if the bot is connected and it is not busy
			if(connection.getText().equals("Connected") & status.getText().equals("Idle") )
			{

				//change the text to print to given text
				c.stringToPrint = input.getText();

				//change status to busy
				status.setBackground( new Color(255,0,0) );
				status.setText("Busy");

				c.repaint();

			}

		}
		//if button pressed to connect
		else if (evt.getSource() == connect)
		{

			//change status to connected
			connection.setText("Connected");
			connection.setBackground( new Color(0,255,0) );

			//if already not busy then only change to idle
			if(!status.getText().equals("Busy"))
			{

				status.setText("Idle");
				status.setBackground( new Color(0,255,0) );

			}

		}

	}

	//finction to change status back to Idle after finishing the writing
	public void statusIdle()
	{

		status.setText("Idle");
		status.setBackground( new Color(0,255,0) );

	}

}

// The applet class starts here
public class CWR2 extends Applet //implements ActionListener
{

	static int dir1=1,dir2=1;
	static Link l1 = new Link(100, 200, 10);
	static Link l2 = new Link(150, 350, 10);

	static
	{

		l1.l = l2;
		l2.bl = l1;
		l2.setFrontOffset(90);
		//l1.setRange(0,180);
		l1.setAngle(270);
		l2.setAngle(270);
		l1.rotate(1);l1.rotate(-1);

	}

	//While Drawing lines on the applet, each line is stored in form of the coordinates
	//so that it can be drawn each time the applet is cleared
	static CoOrdinate points[][] = new CoOrdinate[200][200];
	static int noOfLines = -1;
	static int[] noOfPoints = new int[200];
	static boolean flag = false;
	static boolean penFlag = false;

	//The input from user
	static String stringToPrint;

	//GUI
	Frame_Type f;

	// This method is mandatory, but can be empty (i.e., have no actual code).
	public void init()
	{

		setSize(1280, 500);

		//set parameters for frameset
		f=new Frame_Type(this);
		f.setSize(182, 215);
		f.setVisible(true);

	}

	// This method is mandatory, but can be empty.(i.e.,have no actual code).
	public void stop() { }

	// Print a message on the screen (x=20, y=10).
	public void paint(Graphics g)
	{

		plot(g,this,false);

		if(stringToPrint!=null)
		for(int i = 0; i<stringToPrint.length(); i++)
		{

			draw(stringToPrint.charAt(i),g,this);

		}
		if(stringToPrint!=null)
		f.statusIdle();

		/*draw('A',g,this);

		draw('B',g,this);

		draw('C',g,this);

		draw('D',g,this);

		draw('E',g,this);

		draw('F',g,this);

		draw('G',g,this);

		draw('H',g,this);

		draw('e',g,this);

		draw('J',g,this);

		draw('K',g,this);

		draw('L',g,this);*/

		//repaint();

	}

/*	public void actionPerformed(ActionEvent evt)
	{

		if (evt.getSource() == write)
			stringToPrint = input.getText();

		repaint();

	}*/

	//Overall function to draw each character
	static public void draw(char c, Graphics g, CWR2 cwr)
	{

		//CoOrdinates of the intermidiate 10 points
		CoOrdinate points[] = new CoOrdinate[12];
		//CoOrdinate of the latest position
		CoOrdinate temp = new CoOrdinate();

		//get the coordinate of the latest position
		l2.getTipRef(temp);

		switch(c)
		{

			case 'A':		fill(temp.x,temp.y,-50,100,points);
							plotLine(g,cwr,false,points);

							fill(-50,100,0,0,points);
							plotLine(g,cwr,true,points);

							fill(0,0,50,100,points);
							plotLine(g,cwr,true,points);

							fill(50,100, -25, 50, points);
							plotLine(g,cwr,false,points);

							fill(-25, 50, 25,50, points);
							plotLine(g,cwr,true,points);

							for(int i=0;i<22;i++)
							{

								penFlag = false;
								l1.drag(5);
								plot(g,cwr,false);

							}

						break;

			case 'B':		fill(temp.x,temp.y,-50,100,points);
							plotLine(g,cwr,false,points);

							fill(-50,100,-50,0,points);
							plotLine(g,cwr,true,points);

							fill(-50,0,25,0,points);
							plotLine(g,cwr,true,points);

							fill(25,0,50,25,points);
							plotLine(g,cwr,true,points);

							fill(50,25,25,50,points);
							plotLine(g,cwr,true,points);

							fill(25,50,-50,50,points);
							plotLine(g,cwr,true,points);

							fill(-50,50,25,50,points);
							plotLine(g,cwr,true,points);

							fill(25,50,50,75,points);
							plotLine(g,cwr,true,points);

							fill(50,75,25,100,points);
							plotLine(g,cwr,true,points);

							fill(25,100,-50,100,points);
							plotLine(g,cwr,true,points);

							for(int i=0;i<22;i++)
							{

								penFlag = false;
								l1.drag(5);
								plot(g,cwr,false);

							}

						break;

			case 'C':		fill(temp.x,temp.y,50,25,points);
							plotLine(g,cwr,false,points);

							fill(50,25,25,0,points);
							plotLine(g,cwr,true,points);

							fill(25,0,-25,0,points);
							plotLine(g,cwr,true,points);

							fill(-25,0,-50,25,points);
							plotLine(g,cwr,true,points);

							fill(-50,25,-50,75,points);
							plotLine(g,cwr,true,points);

							fill(-50,75,-25,100,points);
							plotLine(g,cwr,true,points);

							fill(-25,100,25,100,points);
							plotLine(g,cwr,true,points);

							fill(25,100,50,75,points);
							plotLine(g,cwr,true,points);

							for(int i=0;i<22;i++)
							{

								penFlag = false;
								l1.drag(5);
								plot(g,cwr,false);

							}

						break;

			case 'D':		fill(temp.x,temp.y,-50,100,points);
							plotLine(g,cwr,false,points);

							fill(-50,100,-50,0,points);
							plotLine(g,cwr,true,points);

							fill(-50,0,25,0,points);
							plotLine(g,cwr,true,points);

							fill(25,0,50,25,points);
							plotLine(g,cwr,true,points);

							fill(50,25,50,75,points);
							plotLine(g,cwr,true,points);

							fill(50,75,25,100,points);
							plotLine(g,cwr,true,points);

							fill(25,100,-50,100,points);
							plotLine(g,cwr,true,points);

							for(int i=0;i<22;i++)
							{

								penFlag = false;
								l1.drag(5);
								plot(g,cwr,false);

							}

						break;

			case 'E':		fill(temp.x,temp.y,-50,100,points);
							plotLine(g,cwr,false,points);

							fill(-50,100,-50,0,points);
							plotLine(g,cwr,true,points);

							fill(-50,0,50,0,points);
							plotLine(g,cwr,true,points);

							fill(50,0,-50,50,points);
							plotLine(g,cwr,false,points);

							fill(-50,50,25,50,points);
							plotLine(g,cwr,true,points);

							fill(25,50,-50,100,points);
							plotLine(g,cwr,false,points);

							fill(-50,100,50,100,points);
							plotLine(g,cwr,true,points);

							for(int i=0;i<22;i++)
							{

								penFlag = false;
								l1.drag(5);
								plot(g,cwr,false);

							}

						break;

			case 'G':		fill(temp.x,temp.y,50,25,points);
							plotLine(g,cwr,false,points);

							fill(50,25,25,0,points);
							plotLine(g,cwr,true,points);

							fill(25,0,-25,0,points);
							plotLine(g,cwr,true,points);

							fill(-25,0,-50,25,points);
							plotLine(g,cwr,true,points);

							fill(-50,25,-50,75,points);
							plotLine(g,cwr,true,points);

							fill(-50,75,-25,100,points);
							plotLine(g,cwr,true,points);

							fill(-25,100,25,100,points);
							plotLine(g,cwr,true,points);

							fill(25,100,50,75,points);
							plotLine(g,cwr,true,points);

							fill(50,75,50,50,points);
							plotLine(g,cwr,true,points);

							fill(50,50,0,50,points);
							plotLine(g,cwr,true,points);

							for(int i=0;i<22;i++)
							{

								penFlag = false;
								l1.drag(5);
								plot(g,cwr,false);

							}

						break;

			case 'H':		fill(temp.x,temp.y,-50,100,points);
							plotLine(g,cwr,false,points);

							fill(-50,100,-50,0,points);
							plotLine(g,cwr,true,points);

							fill(-50,0,0,0,points);
							plotLine(g,cwr,false,points);

							fill(0,0,0,100,points);
							plotLine(g,cwr,true,points);

							fill(0,100,-50,50,points);
							plotLine(g,cwr,false,points);

							fill(-50,50,0,50,points);
							plotLine(g,cwr,true,points);

							for(int i=0;i<12;i++)
							{

								penFlag = false;
								l1.drag(5);
								plot(g,cwr,false);

							}

						break;

			case 'J':		fill(temp.x,temp.y,-50,0,points);
							plotLine(g,cwr,false,points);

							fill(-50,0,50,0,points);
							plotLine(g,cwr,true,points);

							fill(50,0,-50,75,points);
							plotLine(g,cwr,false,points);

							fill(-50,75,-25,100,points);
							plotLine(g,cwr,true,points);

							fill(-25,100,0,100,points);
							plotLine(g,cwr,true,points);

							fill(0,100,25,75,points);
							plotLine(g,cwr,true,points);

							fill(25,75,25,0,points);
							plotLine(g,cwr,true,points);

							for(int i=0;i<22;i++)
							{

								penFlag = false;
								l1.drag(5);
								plot(g,cwr,false);

							}

						break;

			case 'e':		fill(temp.x,temp.y,-50,60,points);
							plotLine(g,cwr,false,points);

							fill(-50,60,30,60,points);
							plotLine(g,cwr,true,points);

							fill(30,60,30,40,points);
							plotLine(g,cwr,true,points);

							fill(30,40,10,20,points);
							plotLine(g,cwr,true,points);

							fill(10,20,-30,20,points);
							plotLine(g,cwr,true,points);

							fill(-30,20,-50,40,points);
							plotLine(g,cwr,true,points);

							fill(-50,40,-50,80,points);
							plotLine(g,cwr,true,points);

							fill(-50,80,-30,100,points);
							plotLine(g,cwr,true,points);

							fill(-30,100,10,100,points);
							plotLine(g,cwr,true,points);

							fill(10,100,30,80,points);
							plotLine(g,cwr,true,points);

							for(int i=0;i<18;i++)
							{

								penFlag = false;
								l1.drag(5);
								plot(g,cwr,false);

							}

						break;

			case 'W':		fill(temp.x,temp.y,-50,0,points);
							plotLine(g,cwr,false,points);

							fill(-50,0,-25,100,points);
							plotLine(g,cwr,true,points);

							fill(-25,100,0,50,points);
							plotLine(g,cwr,true,points);

							fill(0,50,25,100,points);
							plotLine(g,cwr,true,points);

							fill(25,100,50,0,points);
							plotLine(g,cwr,true,points);

							for(int i=0;i<22;i++)
							{

								penFlag = false;
								l1.drag(5);
								plot(g,cwr,false);

							}

						break;

			case 'r':		fill(temp.x,temp.y,-50,20,points);
							plotLine(g,cwr,false,points);

							fill(-50,20,-30,40,points);
							plotLine(g,cwr,true,points);

							fill(-30,40,-30,100,points);
							plotLine(g,cwr,true,points);

							fill(-30,100,-30,40,points);
							plotLine(g,cwr,true,points);

							fill(-30,40,-10,20,points);
							plotLine(g,cwr,true,points);

							fill(-10,20,10,20,points);
							plotLine(g,cwr,true,points);

							fill(10,20,30,20,points);
							plotLine(g,cwr,true,points);

							for(int i=0;i<18;i++)
							{

								penFlag = false;
								l1.drag(5);
								plot(g,cwr,false);

							}

						break;

			case 'o':		fill(temp.x,temp.y,30,40,points);
							plotLine(g,cwr,false,points);

							fill(30,40,10,20,points);
							plotLine(g,cwr,true,points);

							fill(10,20,-30,20,points);
							plotLine(g,cwr,true,points);

							fill(-30,20,-50,40,points);
							plotLine(g,cwr,true,points);

							fill(-50,40,-50,80,points);
							plotLine(g,cwr,true,points);

							fill(-50,80,-30,100,points);
							plotLine(g,cwr,true,points);

							fill(-30,100,10,100,points);
							plotLine(g,cwr,true,points);

							fill(10,100,30,80,points);
							plotLine(g,cwr,true,points);

							fill(30,80,30,40,points);
							plotLine(g,cwr,true,points);

							for(int i=0;i<18;i++)
							{

								penFlag = false;
								l1.drag(5);
								plot(g,cwr,false);

							}

						break;

			case 'Z':		fill(temp.x,temp.y,-50,0,points);
							plotLine(g,cwr,false,points);

							fill(-50,0,50,0,points);
							plotLine(g,cwr,true,points);

							fill(50,0,-50,100,points);
							plotLine(g,cwr,true,points);

							fill(-50,100,50,100,points);
							plotLine(g,cwr,true,points);

							for(int i=0;i<22;i++)
							{

								penFlag = false;
								l1.drag(5);
								plot(g,cwr,false);

							}

						break;

			case 'T':		fill(temp.x,temp.y,0,0,points);
							plotLine(g,cwr,false,points);

							fill(0,0,0,100,points);
							plotLine(g,cwr,true,points);

							fill(0,100,-50,0,points);
							plotLine(g,cwr,false,points);

							fill(-50,0,50,0,points);
							plotLine(g,cwr,true,points);

							for(int i=0;i<22;i++)
							{

								penFlag = false;
								l1.drag(5);
								plot(g,cwr,false);

							}

						break;

			case 'X':		fill(temp.x,temp.y,-50,0,points);
							plotLine(g,cwr,false,points);

							fill(-50,0,50,100,points);
							plotLine(g,cwr,true,points);

							fill(50,100,50,0,points);
							plotLine(g,cwr,false,points);

							fill(50,0,-50,100,points);
							plotLine(g,cwr,true,points);

							for(int i=0;i<22;i++)
							{

								penFlag = false;
								l1.drag(5);
								plot(g,cwr,false);

							}

						break;

			case 'l':		fill(temp.x,temp.y,-50,0,points);
							plotLine(g,cwr,false,points);

							fill(-50,0,-50,100,points);
							plotLine(g,cwr,true,points);

							for(int i=0;i<2;i++)
							{

								penFlag = false;
								l1.drag(5);
								plot(g,cwr,false);

							}

						break;

			case 'I':		fill(temp.x,temp.y,0,0,points);
							plotLine(g,cwr,false,points);

							fill(0,0,0,100,points);
							plotLine(g,cwr,true,points);

							fill(0,100,-50,0,points);
							plotLine(g,cwr,false,points);

							fill(-50,0,50,0,points);
							plotLine(g,cwr,true,points);

							fill(50,0,-50,100,points);
							plotLine(g,cwr,false,points);

							fill(-50,100,50,100,points);
							plotLine(g,cwr,true,points);

							for(int i=0;i<22;i++)
							{

								penFlag = false;
								l1.drag(5);
								plot(g,cwr,false);

							}

						break;

		}

	}

	//fill the points array with the intermediate points' coordinates
	static public void fill(int xStart, int yStart, int xEnd, int yEnd, CoOrdinate[] points)
	{

		yStart+=50;
		yEnd+=50;

		double inc;
		int i;

		//calculate slope
		double slope = (yEnd-yStart)*1.0/(xEnd-xStart);

		//is x span more than y span
		if( Math.abs(xStart - xEnd) >= Math.abs(yStart - yEnd) )
		{

			//line ends after it starts
			if(xStart<xEnd)
			{

				inc =  (xEnd - xStart)*1.0 / 10;

				points[0]=new CoOrdinate();
				points[0].x=xStart;
				points[0].y=yStart;
				for(i=1 ; i<10 ; i++)
				{

					//find the points in forward direction
					points[i] = new CoOrdinate();
					points[i].x  = (int)( points[i-1].x + inc );
					points[i].y  = (int)( points[i-1].y + slope * ( points[i].x  - points[i-1].x ) );

				}
				points[10]=new CoOrdinate();
				points[10].x=xEnd;
				points[10].y=yEnd;

			}
			//line ends before it starts
			else
			{

				inc =  (xStart - xEnd)*1.0 / 10;

				points[0]=new CoOrdinate();
				points[0].x=xStart;
				points[0].y=yStart;
				for(i=1 ; i<10 ; i++)
				{

					//find the points in reverse direction
					points[i] = new CoOrdinate();
					points[i].x  = (int)( points[i-1].x - inc );
					points[i].y  = (int)( points[i-1].y + slope * ( points[i].x  - points[i-1].x ) );

				}
				points[10]=new CoOrdinate();
				points[10].x=xEnd;
				points[10].y=yEnd;

			}

		}
		//yspan is more than x span
		else
		{

			//line ends after it starts
			if(yStart<yEnd)
			{

				inc =  (yEnd - yStart)*1.0 / 10;

				points[0]=new CoOrdinate();
				points[0].x=xStart;
				points[0].y=yStart;
				for(i=1 ; i<10 ; i++)
				{

					//find the points in forward direction
					points[i] = new CoOrdinate();
					points[i].y  = (int)( points[i-1].y + inc );
					points[i].x  = (int)( points[i-1].x + 1/slope * ( points[i].y  - points[i-1].y ) );

				}
				points[10]=new CoOrdinate();
				points[10].x=xEnd;
				points[10].y=yEnd;

			}
			//line ends before it starts
			else
			{

				inc =  (yStart - yEnd)*1.0 / 10;

				points[0]=new CoOrdinate();
				points[0].x=xStart;
				points[0].y=yStart;
				for(i=1 ; i<10 ; i++)
				{

					//find the points in reverse direction
					points[i] = new CoOrdinate();
					points[i].y  = (int)( points[i-1].y - inc );
					points[i].x  = (int)( points[i-1].x + 1/slope * ( points[i].y  - points[i-1].y ) );

				}
				points[10]=new CoOrdinate();
				points[10].x=xEnd;
				points[10].y=yEnd;

			}

		}


	}

	//function to draw the line by finding out the angles to which the links should rotate
	static public void plotLine(Graphics g, CWR2 c, boolean b, CoOrdinate[] points)
	{
				int X, Y;

				if( !b  & penFlag )
				{

					penFlag = false;
					//pen up graphics


				}
				else if( b & !penFlag )
				{

					penFlag = true;
					//pen down graphics


				}

				//draw all the 10 minisegments
				for(int i=0;i<=10;i++)
				{

					X=points[i].x;
					Y=points[i].y;

					double L = (X*X) + (Y*Y);
		        	L = Math.sqrt(L);

		        	double link1 = l1.getLength();
		        	double link2 = l2.getLength();

		        			double motorAngle2 = (link1*link1)+(link2*link2)-(L*L);
					        motorAngle2 = motorAngle2 / (2*link1*link2);
					        motorAngle2 = Math.acos(motorAngle2);

					// Work out Alpha
					        double Alpha = (link1*link1)+(L*L)-(link2*link2);
					        Alpha = Alpha / (2*link1*L);
					        Alpha = Math.acos(Alpha);

					// Work out Beta
					        double Beta = (float) X/(float) Y;
					        Beta = Math.atan(Beta);

					// Finally work out the motorAngle1 angle
					        double motorAngle1 = Math.PI - Alpha - Beta;

					        Alpha = Math.toDegrees(Alpha);
					        Beta = Math.toDegrees(Beta);

					// Convert the angles to degrees...
					        motorAngle2 = Math.toDegrees(motorAngle2 );
		      				motorAngle1 = Math.toDegrees(motorAngle1) ;

					l1.setAngle(90 - motorAngle1);
					l2.setAngle(90+180-motorAngle1+motorAngle2);

					//g.drawString("X="+X+" "+Double.toString(l1.getAngle()),300,300);
					//g.drawString("Y="+Y+" "+Double.toString(l2.getAngle()),300,400);

					l1.rotate(1);l1.rotate(-1);

					if(!Double.isNaN(l1.getAngle()) & !Double.isNaN(l2.getAngle()) & !Double.isInfinite(l1.getAngle()) & !Double.isInfinite(l2.getAngle()) )
						plot(g,c,b);

				}

	}

	//function that actually draws everything in the applet
	static public void plot(Graphics g, CWR2 c, boolean b)
	{

				clear(g, c);

				//graphics to draw the robot
				int maxX, maxY, minX, minY;
				int tempX, tempY;
				tempX = l1.getOriginX();
				tempY = l1.getOriginY();
				minX = tempX-100;
				maxX = tempX+100;
				maxY = tempY+35-15;
				minY = tempY-95-15;

				g.fillRect(minX, minY, maxX-minX, maxY-minY);

				tempX = (minX + maxX)/2;
				tempY = (minY + maxY)/2 - 15;

				g.setColor(Color.green.darker());
				g.fillArc(tempX-60, tempY-60, 120, 120, 45, -90);
				g.fillArc(tempX-60, tempY-60, 120, 120, 135, 90);
				g.setColor(Color.black);
				g.fillRect(tempX-42, tempY-50, 15, 100);
				g.fillRect(tempX+27, tempY-50, 15, 100);

				g.setColor(Color.black);
				g.drawLine(tempX-42, tempY-35, tempX+42, tempY-35);
				g.drawLine(tempX-42, tempY+35, tempX+42, tempY+35);

				g.drawLine(tempX-42, tempY-35, tempX-42, tempY-42);
				g.drawLine(tempX+42, tempY-35, tempX+42, tempY-42);
				g.drawLine(tempX-42, tempY+35, tempX-42, tempY+42);
				g.drawLine(tempX+42, tempY+35, tempX+42, tempY+42);

				g.setColor(Color.green.darker());
				g.fillRect(tempX-42, tempY-34, 84, 69);

				g.setColor(Color.black);
				g.fillRect(tempX+25, tempY-30, 20, 60);
				g.setColor(Color.green);
				g.fillRect(tempX+27, tempY-28, 16, 56);

				g.setColor(Color.orange);
				g.fillArc(tempX-50, tempY+10, 10, 10, 0, 360);
				g.fillArc(tempX-35, tempY+10, 7, 7, 0, 360);
				g.fillArc(tempX-35, tempY-20, 7, 7, 0, 360);

				g.setColor(new Color(0x33,0x66,0xFF));
				g.fillRect(tempX+45, tempY-15, 12, 30);

				g.setColor(Color.lightGray);
				g.fillArc(tempX-48, tempY+12, 6, 6, 0, 360);
				g.fillArc(tempX-34, tempY+11, 4, 4, 0, 360);
				g.fillArc(tempX-34, tempY-19, 4, 4, 0, 360);
				g.fillRect(tempX-60, tempY-10, 20, 20);
				g.fillArc(tempX+47, tempY-13, 8, 8, 0, 360);
				g.fillArc(tempX+47, tempY-3, 8, 8, 0, 360);
				g.fillArc(tempX+47, tempY+7, 8, 8, 0, 360);

				g.setColor(Color.blue);
				int X[] = {tempX+15, tempX+15, tempX-15, tempX-25, tempX-25, tempX-15};
				int Y[] = {tempY-15, tempY+15, tempY+15, tempY+5, tempY-5, tempY-15};
				g.fillPolygon(X, Y, 6);


				//graphics to draw the links
				l1.draw(g, penFlag);
				l2.draw(g, penFlag);

				//complex calculations to plot each point on the canvas
				if(b)
				{

					if(!flag) noOfLines++;
					flag = true;

				}
				else
					flag  = false;

				if(b)
				{

					points[noOfLines][noOfPoints[noOfLines]] = new CoOrdinate();
					l2.getTip(points[noOfLines][noOfPoints[noOfLines]]);
					noOfPoints[noOfLines]++;

				}

				g.setColor(Color.black);
				for(int i=0; i<=noOfLines; i++)
				{

					if(noOfPoints[i] >= 2)
					{

						for(int j=0; j< noOfPoints[i]-1 ; j++ )
							g.drawLine(points[i][j].x, points[i][j].y, points[i][j+1].x, points[i][j+1].y);

					}

				}

				delay(100);

	}

	//function to induce delay
	static public void delay(int time)
	{

		try
		{

			Thread.sleep(time);

		}
		catch(InterruptedException e)
		{

			e.toString();
			e.printStackTrace();

		}

	}

	//function to clear canvas
	static public void clear(Graphics g, CWR2 c)
	{

		Color b = c.getBackground();
		Color f = c.getForeground();
		g.setColor(b);
		g.fillRect(0,0,800,600);
		g.setColor(f);

	}

}